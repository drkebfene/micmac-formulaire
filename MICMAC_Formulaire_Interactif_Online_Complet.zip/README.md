
# Formulaire Interactif MICMAC – Analyse des Influences Stratégiques

## Présentation

Ce projet contient un formulaire HTML interactif conçu pour réaliser une **analyse structurelle MICMAC** (Matrice d'Impacts Croisés Multiplication Appliquée à un Classement) dans le cadre d’une **étude prospective du système de formation sanitaire** à Moundou (Tchad).

### Auteur :
**Dr Kebféné Moundiné**  
Centre de Recherche, Formation et Expertise en Santé Publique (CREFESP)  
Mai 2025

## Fonctionnalités

- 🧩 Saisie des influences entre variables (0 à 3)
- 📊 Calcul automatique des scores d’**influence** et de **dépendance**
- 💡 Affichage dynamique en tableau de synthèse
- ⚙️ Compatible hors-ligne (HTML autonome)
- 🌐 Prêt à héberger via **GitHub Pages** ou **Netlify**

## Variables du système analysé

1. Financement de la formation  
2. Qualité des infrastructures  
3. Compétences des formateurs  
4. Adéquation des programmes  
5. Partenariats institutionnels

## Utilisation

1. Ouvrez `index.html` dans un navigateur moderne.
2. Renseignez les niveaux d’influence entre variables.
3. Cliquez sur “Afficher Résultat” pour générer automatiquement la matrice Influence ↔ Dépendance.
4. Interprétez les résultats selon la classification MICMAC (motrice, dépendante, autonome, relais).

## Déploiement en ligne

### 📍 GitHub Pages :
- Téléversez ce dépôt sur votre compte GitHub.
- Allez dans **Settings > Pages**
- Activez GitHub Pages sur la branche `main`, répertoire `/root`.

### 🌍 Lien final :
`https://votre-nom-utilisateur.github.io/nom-du-dépôt/`

---

## Licence

Libre de réutilisation à des fins pédagogiques et stratégiques. Veuillez citer l’auteur.

© Dr Kebféné Moundiné, 2025
